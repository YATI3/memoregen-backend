# MemoRegen Frontend
Instructions de déploiement React + i18n